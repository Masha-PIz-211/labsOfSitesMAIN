// 1. setTimeout: 
console.log("Пример setTimeout:");
setTimeout(() => {
    console.log("Это сообщение появилось через 2 секунды!");
}, 2000);

// 2. setInterval: 
console.log("Пример setInterval:");
let count = 0;
const intervalId = setInterval(() => {
    count++;
    console.log(`Сообщение №${count}`);
    if (count === 5) {
        clearInterval(intervalId);
        console.log("setInterval остановлен.");
    }
}, 1000);